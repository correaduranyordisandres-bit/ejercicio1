Algoritmo ejercicio10
    Definir precioArticulo, valorIva Como Real;
    Escribir "Ingrese el precio del art�culo:";
    Leer precioArticulo;
    valorIva <- precioArticulo * 0.19;
    Escribir "El valor correspondiente al IVA (19%) es: $", valorIva;
FinAlgoritmo
