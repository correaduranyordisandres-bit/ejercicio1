Algoritmo ejercicio5
    Definir lado1, lado2, lado3, perimetro Como Real;
    Escribir "Ingrese el valor del primer lado:";
    Leer lado1;
    Escribir "Ingrese el valor del segundo lado:";
    Leer lado2;
    Escribir "Ingrese el valor del tercer lado:";
    Leer lado3;
    perimetro <- lado1 + lado2 + lado3;
    Escribir "El per�metro del tri�ngulo es: ", perimetro;
FinAlgoritmo
